<!DOCTYPE html>

<html>
<head>
<title>Admin</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<!-- menu -->

        <ul class="nav nav-tabs" role="tablist" style="background-color: white;">
          <li class="nav-item">
            <a class="nav-link btn-outline-warning active" data-toggle="tab" href="#home">Edit Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link btn-outline-warning" data-toggle="tab" href="#profil">Edit Biodata</a>
          </li>
          <li class="nav-item">
            <a class="nav-link btn-outline-warning" data-toggle="tab" href="#pendidikan">Edit Info Pendidikan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link btn-outline-warning" data-toggle="tab" href="#karya">Edit Info Karya</a>
          </li>
          <li class="nav-item">
            <a class="nav-link btn-outline-warning" data-toggle="tab" href="#sertifikat">Edit Info Sertifikat</a>
          </li>
          <li class="nav-item">
            <a class="nav-link btn-outline-warning" data-toggle="tab" href="#footer">Edit Info Footer</a>
          </li>
        </ul>
  <div class="tab-content">
<!--======================== Home ==========================-->
         <div id="home" class="container tab-pane active">
              <div class="row">
                <div class="col-md-12">
                <h1>Edit Home</h1>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                <table id="listtable" class="table table-striped">
                  <thead>
                    <tr>
                      <th>Kode</th>
                      <th>Nama Wb</th>
                      <th>Nama Pembuat</th>
                      <th>Moto Hidup</th>
                      <th>Logo</th>
                      <th>Edit</th>
                    </tr>
                  </thead>
              <tbody>
                <?php
                include_once "koneksi.php";
                //buat sql
                $strSQL = "SELECT * FROM home";
                $runStrSQL = mysqli_query($conn,$strSQL);
                $jmlRowData = mysqli_num_rows($runStrSQL);
                if ($jmlRowData < 0) {
                  echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
                }
                else {
                  while($row = mysqli_fetch_assoc($runStrSQL)) {
                ?>
                    <tr style="background-color:  black; color: white;">
                      <td><?php echo $row["id"] ?></td>
                      <td><?php echo $row["nama_web"] ?></td>
                      <td><?php echo $row["nama_pembuat"] ?></td>
                      <td><?php echo $row["moto_hidup"] ?></td>
                      <td><?php echo $row["logo"] ?></td>
                    <td>
                        <a href="edit_home.php?id=<?php echo $row["id"]; ?>" class="btn btn-info">Edit</a></td>
                    </tr>
                    </tr>
                <?php 
                  }
                }
                ?>
              </tbody>
            </table>
          </div>
          </div>
        </div>
<!--=========================== Biodata ============================-->
        <div id="profil" class="container tab-pane fade">
              <div class="row">
                <div class="col-md-12">
                <h1>Edit Biodata</h1>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                <table id="listtable" class="table table-striped">
                  <thead>
                    <tr>
                      <th>Kode</th>
                      <th>Nama Lengkap</th>
                      <th>NIM</th>
                      <th>Tempat Lahir</th>
                      <th>Tanggal Lahir</th>
                      <th>Hobi</th>
                      <th>Alamat</th>
                      <th>Nama SD</th>
                      <th>Nama SMP</th>
                      <th>Nama SMK</th>
                      <th>Nama Kampus</th>
                      <th>Foto</th>
                      <th>Edit</th>
                    </tr>
                  </thead>
              <tbody>
                <?php
                include_once "koneksi.php";
                //buat sql
                $strSQL = "SELECT * FROM biodata";
                $runStrSQL = mysqli_query($conn,$strSQL);
                $jmlRowData = mysqli_num_rows($runStrSQL);
                if ($jmlRowData < 0) {
                  echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
                }
                else {
                  while($row = mysqli_fetch_assoc($runStrSQL)) {
                ?>
                    <tr style="background-color:  black; color: white;">
                      <td><?php echo $row["id"] ?></td>
                      <td><?php echo $row["nama"] ?></td>
                      <td><?php echo $row["nim"] ?></td>
                      <td><?php echo $row["tempatlahir"] ?></td>
                      <td><?php echo $row["tanggallahir"] ?></td>
                      <td><?php echo $row["hobi"] ?></td>
                      <td><?php echo $row["alamat"] ?></td>
                      <td><?php echo $row["sd"] ?></td>
                      <td><?php echo $row["smp"] ?></td>
                      <td><?php echo $row["smk"] ?></td>
                      <td><?php echo $row["kampus"] ?></td>
                      <td><?php echo $row["foto"] ?></td>
                      <td>
                        <a href="edit_biodata.php?id=<?php echo $row["id"]; ?>" class="btn btn-info">Edit</a></td>
                    </tr>
                <?php 
                  }
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
      </div>
<!--=========================== INFO PENDIDIKAN ============================-->
        <div id="pendidikan" class="container tab-pane fade">
              <div class="row">
                <div class="col-md-12">
                <h1>Edit Info Pendidikan</h1>
                </div>
              </div>
              <a href="tambah_pendidikan.php" class="btn btn-primary">Tambah Data</a>
              <div class="row">
                <div class="col-md-12">
                <table id="listtable" class="table table-striped">
                  <thead>
                    <tr>
                      <th>Kode</th>
                      <th>Nama</th>
                      <th>Jenjang Pendidikan</th>
                      <th>Status</th>
                      <th>Pemimpin</th>
                      <th>Alamat</th>
                      <th>Kelurahan</th>
                      <th>Kecamatan</th>
                      <th>Kota</th>
                      <th>Provinsi</th>
                      <th>Foto</th>
                      <th>Edit</th>
                    </tr>
                  </thead>
              <tbody>
                <?php
                include_once "koneksi.php";
                //buat sql
                $strSQL = "SELECT * FROM pendidikan";
                $runStrSQL = mysqli_query($conn,$strSQL);
                $jmlRowData = mysqli_num_rows($runStrSQL);
                if ($jmlRowData < 0) {
                  echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
                }
                else {
                  while($row = mysqli_fetch_assoc($runStrSQL)) {
                ?>
                    <tr style="background-color:  black; color: white;">
                      <td><?php echo $row["id"] ?></td>
                      <td><?php echo $row["nama"] ?></td>
                      <td><?php echo $row["jenjang"] ?></td>
                      <td><?php echo $row["status"] ?></td>
                      <td><?php echo $row["pemimpin"] ?></td>
                      <td><?php echo $row["alamat"] ?></td>
                      <td><?php echo $row["kel"] ?></td>
                      <td><?php echo $row["kec"] ?></td>
                      <td><?php echo $row["kota"] ?></td>
                      <td><?php echo $row["provinsi"] ?></td>
                      <td><?php echo $row["foto"] ?></td>
                      <td>
                          <a href="edit_pendidikan.php?id=<?php echo $row["id"] ?>" class="btn btn-info">Edit</a>
                      </td>
                    </tr>

                <?php 

                  }
                }
                ?>
                <p>*Maximal hanya 4 data</p>
                </tbody>
              </table>
            </div>
            </div>
        </div>
<!--=========================== INFO KARYA ============================-->
        <div id="karya" class="container tab-pane fade">
              <div class="row">
                <div class="col-md-12">
                <h1>Edit Info Karya</h1>
                </div>
              </div>
              <a href="tambah_karya.php" class="btn btn-primary">Tambah Data</a>
              <div class="row">
                <div class="col-md-12">
                <table id="listtable" class="table table-striped">
                  <thead>
                    <tr>
                      <th>Kode</th>
                      <th>Nama</th>
                      <th>Arti</th>
                      <th>Tanggal</th>
                      <th>Foto</th>
                      <th>Edit</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    include_once "koneksi.php";
                    //buat sql
                    $strSQL = "SELECT * FROM karya";
                    $runStrSQL = mysqli_query($conn,$strSQL);
                    $jmlRowData = mysqli_num_rows($runStrSQL);
                    if ($jmlRowData < 0) {
                      echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
                    }
                    else {
                      while($row = mysqli_fetch_assoc($runStrSQL)) {
                    ?>
                        <tr style="background-color:  black; color: white;">
                          <td><?php echo $row["id"] ?></td>
                          <td><?php echo $row["nama"] ?></td>
                          <td><?php echo $row["arti"] ?></td>
                          <td><?php echo $row["tanggal"] ?></td>
                          <td><?php echo $row["foto"] ?></td>
                          <td>
                              <a href="edit_karya.php?id=<?php echo $row["id"] ?>" class="btn btn-info">Edit</a></td>
                         </tr>
                         
                    <?php 
                      }
                    }
                    ?>
                    <p>*Maximal hanya 3 data</p>
                  </tbody>
                </table>
              </div>
            </div>
        </div>
<!--=========================== INFO SERTIFIKAT ============================-->
        <div id="sertifikat" class="container tab-pane fade">
              <div class="row">
                <div class="col-md-12">
                <h1>Edit Info Sertifikat</h1>
                </div>
              </div>
              <a href="tambah_sertifikat.php" class="btn btn-primary">Tambah Data</a>
              <div class="row">
                <div class="col-md-12">
                <table id="listtable" class="table table-striped">
                  <thead>
                    <tr>
                      <th>Kode</th>
                      <th>Nama</th>
                      <th>Informasi</th>
                      <th>Tanggal</th>
                      <th>Foto</th>
                      <th>Edit</th>
                    </tr>
                  </thead>
              <tbody>
                <?php
                include_once "koneksi.php";
                //buat sql
                $strSQL = "SELECT * FROM sertifikat";
                $runStrSQL = mysqli_query($conn,$strSQL);
                $jmlRowData = mysqli_num_rows($runStrSQL);
                if ($jmlRowData < 0) {
                  echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
                }
                else {
                  while($row = mysqli_fetch_assoc($runStrSQL)) {
                ?>
                    <tr style="background-color:  black; color: white;">
                      <td><?php echo $row["id"] ?></td>
                      <td><?php echo $row["nama"] ?></td>
                      <td><?php echo $row["info"] ?></td>
                      <td><?php echo $row["tanggal"] ?></td>
                      <td><?php echo $row["foto"] ?></td>
                      <td>
                          <a href="edit_sertifikat.php?id=<?php echo $row["id"] ?>" class="btn btn-info">Edit</a></td>
                    </tr>
                    
                <?php 
                  }
                }
                ?>
                <p>*Maximal hanya 3 data</p>
                  </tbody>
                </table>
              </div>
            </div>
        </div>
<!-- =====================================FOOTERna============================================== -->
        <div id="footer" class="container tab-pane fade"> 
              <div class="row">
                <div class="col-md-12">
                <h1>Edit Info Footer</h1>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <table id="listtable" class="table table-striped">
                    <thead>
                      <tr>
                        <th>Kode</th>
                        <th>Pembuat</th>
                        <th>Nama Ig</th>
                        <th>Nama Fb</th>
                        <th>Email</th>
                        <th>No Telpon</th>
                        <th>Alamat</th>
                        <th>Edit</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      include_once "koneksi.php";
                      //buat sql
                      $strSQL = "SELECT * FROM footer";
                      $runStrSQL = mysqli_query($conn,$strSQL);
                      $jmlRowData = mysqli_num_rows($runStrSQL);
                      if ($jmlRowData < 0) {
                        echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
                      }
                      else {
                        while($row = mysqli_fetch_assoc($runStrSQL)) {
                      ?>
                        <tr style="background-color:  black; color: white;">              
                            <td><?php echo $row["id"] ?></td>
                            <td><?php echo $row["pembuat"] ?></td>
                            <td><?php echo $row["ig"] ?></td>
                            <td><?php echo $row["fb"] ?></td>
                            <td><?php echo $row["email"] ?></td>
                            <td><?php echo $row["telpon"] ?></td>
                            <td><?php echo $row["alamat"] ?></td>
                            <td>
                                <a href="edit_footer.php?id=<?php echo $row["id"] ?>" class="btn btn-info">Edit</a>
                            </td>
                        </tr>
                      <?php 
                        }
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
        </div>
  </div>
<!-- Footer -->
<div class="wrapper row4">
  <footer id="" class="hoc clear"> 
    <div id="copyright" class="hoc clear"> 
    <p class="fl_left">Copyright &copy; 2020 - Rayhan Baihaqi</p>
  </div>
  </footer>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<!-- IE9 Placeholder Support -->
<script src="layout/scripts/jquery.placeholder.min.js"></script>
<!-- / IE9 Placeholder Support -->
</body>
</html>