<!DOCTYPE html>

<html>
<head>
<title>Portofolio</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body id="top">

<!-- menu -->
<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <nav id="mainav" class="fl_left">
      <ul class="clear">
        <li><a href="index.php">Home</a></li>
        <li><a href="biodata.php">Biodata</a></li>
        <li><a href="pendidikan.php">Pendidikan</a></li>
        <li><a href="karya.php">Karya</a></li>
        <li><a href="sertifikat.php">Sertifikat</a></li>
      </ul>
    </nav>
  </div>
</div>
<!-- Home -->
<div class="wrapper row1 colouredborder">
  <header id="header" class="hoc clear"> 
    <?php
        include_once "koneksi.php";
        //buat sql
        $strSQL = "SELECT * FROM home";
        $runStrSQL = mysqli_query($conn,$strSQL);
        $jmlRowData = mysqli_num_rows($runStrSQL);
        if ($jmlRowData < 0) {
          echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
        }
        else {
          while($row = mysqli_fetch_assoc($runStrSQL)) {
        ?>
    <div id="logo"><img style="width: 200px;
        height: 200px;" src="<?php echo $row["logo"] ?>" alt="">
      <h1><a href="index.php"><?php echo $row["nama_web"] ?></a></h1>
      <p><?php echo $row["moto_hidup"] ?></p>
    </div>
  </header>
</div>
<!-- Top Background Image Wrapper -->
<div id="profil" class="bgded" style="background-image:url('img/bg1.jpg');" style="width: 1950px; height: 869px;"> 
  <div class="wrapper">
    <article id="pageintro" class="hoc clear"> 
      <i class="fa fa-dot-circle-o"></i>
      <h2 class="heading"><?php echo $row["nama_pembuat"] ?></h2>
      <?php 
          }
        }
      ?>
      <footer><a class="btn" href="biodata.php">Lihat Biodata</a></footer>
    </article>
  </div>

  <!-- quoc -->
  <div class="wrapper row2">
    <div id="introblocks" class="hoc clear"> 
      <article class="one_third first"><span>R</span>
        <footer><a href="#"><i class="fa fa-angle-double-right"></i></a></footer>
        <h3 class="heading">Raih</h3>
        <p>Teruslah raih mimpimu hingga kamu mendapatkannya.</p>
      </article>
      <article class="one_third"><span>A</span>
        <footer><a href="#"><i class="fa fa-angle-double-right"></i></a></footer>
        <h3 class="heading">Ambil</h3>
        <p>Ambillah ilmu, makna, dan apapun yang membuat kamu bangkit ambillah.</p>
      </article>
      <article class="one_third"><span>Y</span>
        <footer><a href="#"><i class="fa fa-angle-double-right"></i></a></footer>
        <h3 class="heading">Yang Sabar</h3>
        <p>Tetap sabar meskipun apapun itu yang ada di dipanmu.</p>
      </article>
      <div class="clear"></div>
    </div>
  </div>
</div>

<!-- KARYA -->
<div id="karya" class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <div class="btmspace-50 center">
      <h2>Karya yang pernah di buat</h2>
      <p>Karya dibuat karena hanya ke isengan semata, tanpa menyinggung siapapun dan tanpa maksud apapun.</p>
    </div>
    
      <?php
        include_once "koneksi.php";
        //buat sql
        $strSQL = "SELECT * FROM karya";
        $runStrSQL = mysqli_query($conn,$strSQL);
        $jmlRowData = mysqli_num_rows($runStrSQL);
        if ($jmlRowData < 0) {
          echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
        }
        else {
          while($row = mysqli_fetch_assoc($runStrSQL)) {
        ?>
        <div class="card mb-3" style="max-width: 540px;"  id="<?php echo $row["id"] ?>">
          <div class="row no-gutters">
            <div class="col-md-4">
              <img style="width: 300px;height: 300px;" src="<?php echo $row["foto"] ?>" alt="">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <i class="fa fa-calendar-o"></i> <?php echo $row["tanggal"] ?>
                <h5 class="card-title"><?php echo $row["nama"] ?></h5>
                <p class="card-text"><?php echo $row["arti"] ?></p>
              </div>
            </div>
          </div>
        </div>
      <?php 
          }
        }
        ?>
    <div class="clear"></div>
  </main>
</div>
<!--==========================================PENDIDIKAN========================================-->
<div id="pendidikan" class="bgded overlay" style="background-image:url('img/bg2.jpg);" style="width: 1950px;height: 314px;">
  <div class="hoc container clear"> 
    <article class="one_third first">
      <h2>Pendidikan</h2>
      <p>Riwayat pendidikan dari sekolah dasar hingga perguruan tinggi.</p>
    </article>
    <figure class="two_third">
      <ul class="nospace group">
        <?php
              include_once "koneksi.php";
              //buat sql
              $strSQL = "SELECT * FROM pendidikan";
              $runStrSQL = mysqli_query($conn,$strSQL);
              $jmlRowData = mysqli_num_rows($runStrSQL);
              if ($jmlRowData < 0) {
                echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
              }
              else {
                while($row = mysqli_fetch_assoc($runStrSQL)) {
        ?>
        <li class="one_third first btmspace-30">
          <a class="opacity" href="pendidikan1.php?id=<?php echo $row["id"] ?>">
            <img style="width: 180px; height: 60px;" src="<?php echo $row["foto"] ?>" alt="">
          </a>
        </li>
        <?php 
                }
              }
        ?>
      </ul>
    </figure>
  </div>
</div>
<!--=====================================SERTIFIKAT================================================-->
<div id="sertifikat" class="wrapper row3">
  <section class="hoc container clear"> 
    <div class="btmspace-50 center">
      <h2>Sertifikat yang dimiliki</h2>
      <p>Berikut beberapa sertifikat yang dimiliki</p>
    </div>
          <?php
        include_once "koneksi.php";
        //buat sql
        $strSQL = "SELECT * FROM sertifikat";
        $runStrSQL = mysqli_query($conn,$strSQL);
        $jmlRowData = mysqli_num_rows($runStrSQL);
        if ($jmlRowData < 0) {
          echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
        }
        else {
          while($row = mysqli_fetch_assoc($runStrSQL)) {
        ?>
        <div class="card mb-3" style="max-width: 540px;"  id="<?php echo $row["id"] ?>">
          <div class="row no-gutters">
            <div class="col-md-4">
              <img style="width: 320px;height: 220px;" src="<?php echo $row["foto"] ?>" alt="">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <i class="fa fa-calendar-o"></i> <?php echo $row["tanggal"] ?>
                <h5 class="card-title"><?php echo $row["nama"] ?></h5>
                <p class="card-text"><?php echo $row["info"] ?></p>
              </div>
            </div>
          </div>
        </div>

          <?php 
          }
        }
        ?>
  </section>
</div>
<!--=======================================FOOTER==========================================-->
<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
    <div class="one_third first">
      <h6 class="title">Alamat & Kontak</h6>
      <ul class="nospace linklist contact">
        <?php
        include_once "koneksi.php";
        //buat sql
        $strSQL = "SELECT * FROM footer";
        $runStrSQL = mysqli_query($conn,$strSQL);
        $jmlRowData = mysqli_num_rows($runStrSQL);
        if ($jmlRowData < 0) {
          echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
        }
        else {
          while($row = mysqli_fetch_assoc($runStrSQL)) {
        ?>
        <li><i class="fa fa-map-marker"></i>
          <address>
          <?php echo $row["alamat"] ?>
          </address>
        </li>
        <li><i class="fa fa-phone"></i> <?php echo $row["telpon"] ?></li>
      </ul>
    </div>
    <div class="one_third quarter">
      <h6 class="title">Sosial Media</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-facebook-official" aria-hidden="true"></i><?php echo $row["fb"] ?>
        </li>
        <li><i class="fa fa-instagram" aria-hidden="true"></i><?php echo $row["ig"] ?></li>
      </ul>
    </div>
    <div class="one_third quarter">
      <h6 class="title">Pembuat</h6>
      <ul class="nospace linklist">
        <li>
          <article>
            <h2 class="nospace font-x1"><?php echo $row["pembuat"] ?></h2>
          </article>
        </li>
        <?php 
          }
        }
        ?>
      </ul>
    </div>
  </footer>
</div>
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <p class="fl_left">Copyright &copy; 2020 - Rayhan Baihaqi</p>
  </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<!-- IE9 Placeholder Support -->
<script src="layout/scripts/jquery.placeholder.min.js"></script>
<!-- / IE9 Placeholder Support -->
</body>
</html>