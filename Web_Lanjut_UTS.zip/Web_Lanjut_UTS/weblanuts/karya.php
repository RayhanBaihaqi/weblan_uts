<!DOCTYPE html>

<html>
<head>
<title>Portofolio</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body id="top">

<!-- menu -->
<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <nav id="mainav" class="fl_left">
      <ul class="clear">
        <li><a href="index.php" >Home</a></li>
        <li><a href="biodata.php" >Biodata</a></li>
        <li><a href="pendidikan.php" >Pendidikan</a></li>
        <li><a href="karya.php" >Karya</a></li>
        <li><a href="sertifikat.php" >Sertifikat</a></li>
      </ul>
    </nav>
  </div>
</div>
<div id="karya" class="wrapper row3">
  <main class="hoc container clear"> 
      <?php
        include_once "koneksi.php";
        //buat sql
        $strSQL = "SELECT * FROM karya";
        $runStrSQL = mysqli_query($conn,$strSQL);
        $jmlRowData = mysqli_num_rows($runStrSQL);
        if ($jmlRowData < 0) {
          echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
        }
        else {
          while($row = mysqli_fetch_assoc($runStrSQL)) {
        ?>
        <div class="card mb-3" style="max-width: 540px;"  id="<?php echo $row["id"] ?>">
          <div class="row no-gutters">
            <div class="col-md-4">
              <img style="width: 300px;height: 300px;" src="<?php echo $row["foto"] ?>" alt="">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <i class="fa fa-calendar-o"></i> <?php echo $row["tanggal"] ?>
                <h5 class="card-title"><?php echo $row["nama"] ?></h5>
                <p class="card-text"><?php echo $row["arti"] ?></p>
              </div>
            </div>
          </div>
        </div>
      <?php 
          }
        }
        ?>
    </main>
  </div>
<!--=================================================================================-->
<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
    <div class="one_third first">
      <h6 class="title">Alamat & Kontak</h6>
      <ul class="nospace linklist contact">
        <?php
        include_once "koneksi.php";
        //buat sql
        $strSQL = "SELECT * FROM footer";
        $runStrSQL = mysqli_query($conn,$strSQL);
        $jmlRowData = mysqli_num_rows($runStrSQL);
        if ($jmlRowData < 0) {
          echo "<tr><td colspan='4'>Data Tidak Terdapat Dalam Database</td></tr>";    
        }
        else {
          while($row = mysqli_fetch_assoc($runStrSQL)) {
        ?>
        <li><i class="fa fa-map-marker"></i>
          <address>
          <?php echo $row["alamat"] ?>
          </address>
        </li>
        <li><i class="fa fa-phone"></i> <?php echo $row["telpon"] ?></li>
      </ul>
    </div>
    <div class="one_third quarter">
      <h6 class="title">Sosial Media</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-facebook-official" aria-hidden="true"></i><?php echo $row["fb"] ?>
        </li>
        <li><i class="fa fa-instagram" aria-hidden="true"></i><?php echo $row["ig"] ?></li>
      </ul>
    </div>
    <div class="one_third quarter">
      <h6 class="title">Pembuat</h6>
      <ul class="nospace linklist">
        <li>
          <article>
            <h2 class="nospace font-x1"><?php echo $row["pembuat"] ?></h2>
          </article>
        </li>
        <?php 
          }
        }
        ?>
      </ul>
    </div>
  </footer>
</div>
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <p class="fl_left">Copyright &copy; 2020 - Rayhan Baihaqi</p>
  </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<!-- IE9 Placeholder Support -->
<script src="layout/scripts/jquery.placeholder.min.js"></script>
<!-- / IE9 Placeholder Support -->
</body>
</html>