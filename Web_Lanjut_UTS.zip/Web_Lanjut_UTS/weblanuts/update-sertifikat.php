<?php
     include_once "koneksi.php";
     if (isset($_POST["nama"])) {
            
        $nama = $_POST["nama"];
        $info = $_POST["info"];
        $tanggal = $_POST["tanggal"];
        $foto = $_POST["foto"];
        $id = $_POST["id"];
        $strSQL = "UPDATE sertifikat SET nama='$nama', info='$info', tanggal='$tanggal', foto='$foto' WHERE id='$id'";

        $runSQL = mysqli_query($conn, $strSQL);
        if ($runSQL) {
            header("location: admin.php");
        }  
        else {
            die; 
        }       
    }    
?>