<?php
     include_once "koneksi.php";
     if (isset($_POST["nama_web"])) {
            
        $nama_web = $_POST["nama_web"];
        $nama_pembuat = $_POST["nama_pembuat"];
        $moto_hidup = $_POST["moto_hidup"];
        $logo = $_POST["logo"];
        $id = $_POST["id"];
        $strSQL = "UPDATE home SET nama_web='$nama_web', nama_pembuat='$nama_pembuat', moto_hidup='$moto_hidup', logo='$logo' WHERE id='$id'";

        $runSQL = mysqli_query($conn, $strSQL);
        if ($runSQL) {
            header("location: admin.php");
        }  
        else {
            die; 
        }       
    }    
?>