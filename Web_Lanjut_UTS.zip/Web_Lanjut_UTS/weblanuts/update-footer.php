<?php
     include_once "koneksi.php";
     if (isset($_POST["pembuat"])) {
            
        $pembuat = $_POST["pembuat"];
        $ig = $_POST["ig"];
        $fb = $_POST["fb"];
        $email = $_POST["email"];
        $telpon = $_POST["telpon"];
        $alamat = $_POST["alamat"];
        $id = $_POST["id"];
        $strSQL = "UPDATE footer SET pembuat='$pembuat', ig='$ig', fb='$fb', email='$email', telpon='$telpon', alamat='$alamat' WHERE id='$id'";

        $runSQL = mysqli_query($conn, $strSQL);
        if ($runSQL) {
            header("location: admin.php");
        }  
        else {
            die; 
        }       
    }    
?>