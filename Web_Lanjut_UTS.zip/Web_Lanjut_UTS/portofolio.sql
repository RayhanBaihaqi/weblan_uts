-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Nov 2020 pada 21.25
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portofolio`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `biodata`
--

CREATE TABLE `biodata` (
  `id` int(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nim` int(50) NOT NULL,
  `tempatlahir` varchar(100) NOT NULL,
  `tanggallahir` varchar(100) NOT NULL,
  `hobi` varchar(25) NOT NULL,
  `alamat` text NOT NULL,
  `sd` varchar(50) NOT NULL,
  `smp` varchar(50) NOT NULL,
  `smk` varchar(50) NOT NULL,
  `kampus` varchar(50) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `biodata`
--

INSERT INTO `biodata` (`id`, `nama`, `nim`, `tempatlahir`, `tanggallahir`, `hobi`, `alamat`, `sd`, `smp`, `smk`, `kampus`, `foto`) VALUES
(1, 'Rayhan Baihaqi', 2018071014, 'Tangerang', '25 Januari 2000', 'Main Game', 'Jl. Masjid Nurul Fajri', 'sd jaya', 'smp jaya', 'smk jaya', 'universitas jaya', 'img/foto.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `footer`
--

CREATE TABLE `footer` (
  `id` int(10) NOT NULL,
  `pembuat` varchar(30) NOT NULL,
  `ig` varchar(30) NOT NULL,
  `fb` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `telpon` varchar(30) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `footer`
--

INSERT INTO `footer` (`id`, `pembuat`, `ig`, `fb`, `email`, `telpon`, `alamat`) VALUES
(1, 'Rayhan Baihaqi', '@rayhanbaihaqiii', 'Rayhan Baihaqi', 'Rayhanbaihaqi153@gmail.com', '+62 8771464314', 'Jl. Masjid Nurul Majri RT.004/002');

-- --------------------------------------------------------

--
-- Struktur dari tabel `home`
--

CREATE TABLE `home` (
  `id` int(11) NOT NULL,
  `nama_web` varchar(50) NOT NULL,
  `nama_pembuat` varchar(50) NOT NULL,
  `moto_hidup` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `home`
--

INSERT INTO `home` (`id`, `nama_web`, `nama_pembuat`, `moto_hidup`, `logo`) VALUES
(1, 'Rayhan ', 'Rayhan Baihaqi', 'Terus berjalan meski banyak rintangan.', 'img/logo.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `karya`
--

CREATE TABLE `karya` (
  `id` int(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `arti` text NOT NULL,
  `tanggal` varchar(30) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `karya`
--

INSERT INTO `karya` (`id`, `nama`, `arti`, `tanggal`, `foto`) VALUES
(1, 'Logo Alumni Akuntansi', 'Logo ini dibuat untuk alumni akuntansi saya saat smk, Logo ini memiliki warna merah yang berharti berani dan bentuk logo ini gabungan dari dua huruf yaitu A dan K', '01/08/2020', 'img/k1.png'),
(2, 'Logo Organisasi IRMANUF', 'Logo ini di buat untuk organisasi Ikatan Remaja masjid Nurul Fajri (IRMANUF)', '20/06/2018', 'img/k2.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendidikan`
--

CREATE TABLE `pendidikan` (
  `id` int(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenjang` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL,
  `pemimpin` varchar(30) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `kel` varchar(40) NOT NULL,
  `kec` varchar(40) NOT NULL,
  `kota` varchar(40) NOT NULL,
  `provinsi` varchar(40) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pendidikan`
--

INSERT INTO `pendidikan` (`id`, `nama`, `jenjang`, `status`, `pemimpin`, `alamat`, `kel`, `kec`, `kota`, `provinsi`, `foto`) VALUES
(1, 'MI NURUL HUDA', 'Sekolah Dasar', 'Swasta', 'Siti Mutiya', 'Jl. Raya Pondok Aren', 'Sekolah Dasar', 'Pondok Aren', 'Tangerang Selatan', 'Banten', 'img/pe1.png'),
(2, 'Mts AL - SA\'ADAH', 'Sekolah Menengah Pertama (SMP)', 'Swasta', 'Drs.H. Abdul Karim Jafar, M.M', 'Jl. Raya Pondok Aren', 'Pondok Jaya', 'Pondok Aren', 'Tangerang Selatan', 'Banten', 'img/pe2.png'),
(3, 'SMK BAHAGIA', 'Sekolah Menengah Kejuruan (SMK', 'Swasta', 'sasmita sari', 'Jl. Raya pondok Aren', 'Pondok Jaya', 'Pondok Aren', 'Tangerang Selatan', 'Banten', 'img/pe3.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sertifikat`
--

CREATE TABLE `sertifikat` (
  `id` int(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `info` text NOT NULL,
  `tanggal` varchar(30) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `sertifikat`
--

INSERT INTO `sertifikat` (`id`, `nama`, `info`, `tanggal`, `foto`) VALUES
(1, 'Sertifikat CISCO', 'sertifikasi pelatihan CISCO', '01/08/2020', 'img/s1.jpg'),
(2, 'Sertifikat ORACLE Academy', 'Menjadi peserta seminar yang di selanggarakan oleh ORACLE Akademi Yang berteme IOT Internet of Things - Smart Devices', '27/09/2018', 'img/s2.jpg');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `biodata`
--
ALTER TABLE `biodata`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `footer`
--
ALTER TABLE `footer`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `karya`
--
ALTER TABLE `karya`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `sertifikat`
--
ALTER TABLE `sertifikat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `biodata`
--
ALTER TABLE `biodata`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `footer`
--
ALTER TABLE `footer`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `home`
--
ALTER TABLE `home`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `karya`
--
ALTER TABLE `karya`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `sertifikat`
--
ALTER TABLE `sertifikat`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
