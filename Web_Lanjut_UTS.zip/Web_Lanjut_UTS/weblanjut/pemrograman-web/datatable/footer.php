<div class="container-fluid bg-dark text-white text-center p-3 m-2">
    <div class="row"> 
        <div class="col-md-12">
            Copyright &copy Aplikasi XYZ 2020
        </div>
    </div>
</dive>