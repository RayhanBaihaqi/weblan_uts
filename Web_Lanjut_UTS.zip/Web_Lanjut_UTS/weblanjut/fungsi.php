<<?php 
	function fungsiku($namaDepan, $namaBelakang)
	{
		echo "halo fungsi";
		echo "<br>Nama Saya". $namaDepan" ". $namaBelakang ;
	}
 ?>
 <!DOCTYPE html>
 <html>
 <head>

 	<title></title>
 </head>
 <body>
 <?php
 	fungsiku("Rayhan, baihaqi")
 ?>
 </body>
 </html>