<div class="jumbotron text-center" style="margin-bottom:0">
  <h1>Data Mahasiswa Informatika UPJ</h1>
  <p>Website ini Merupakan Data Mahasiswa Informatika UPJ</p> 
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="listdatamahasiswa.php">Data Mahasiswa</a>
      </li>
    </ul>
  </div>  
</nav>