<?php
$isiArtikel = "Ini Adalah Artikel London";
if ($kota == 3){
    $isiArtikel = "Ini Adalah Artikel Tokyo";
}
elseif ($kota == 2){
    $isiArtikel = "Ini Adalah Artikel Paris";
}
?>
<h2><?php echo $isiArtikel ?></h2>