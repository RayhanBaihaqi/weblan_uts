
<!DOCTYPE html>
<html>
<head>
    <title>Portofolio</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <title></title>
</head>
<body>
    <div class="container">
            <div class="row">
                <a href="admin.php"><button type="button" class="btn btn-warning">Kembali</button></a>
                <div class="col-md-12">
                    <?php
                    include_once "koneksi.php";
                    if (isset($_GET['id'])) {
                        $id = $_GET['id'];
                        $strSQL = "SELECT * FROM biodata WHERE id='$id'";
                        $runStrSQL = mysqli_query($conn,$strSQL);
                        $jmlRowData = mysqli_num_rows($runStrSQL);
                        if ($jmlRowData > 0) {
                            while($row = mysqli_fetch_assoc($runStrSQL)) {
                                $id = $row["id"];
                                $nama = $row["nama"];
                                $nim = $row["nim"];
                                $tempatlahir = $row["tempatlahir"];
                                $tanggallahir = $row["tanggallahir"];
                                $hobi = $row["hobi"];
                                $alamat = $row["alamat"];
                                $sd = $row["sd"];
                                $smp = $row["smp"];
                                $smk = $row["smk"];
                                $kampus = $row["kampus"];
                                $foto = $row["foto"];
                    ?>
                    <h2>Edit Biodata</h2>
                    <form id="myform" method="POST" action="update-biodata.php">
                        <div class="form-group">
                            <input id="id" class="form-control" type="hidden" name="id" value="<?php echo $id ?>">
                            <label>Nama Karya:</label>
                            <input type="text" class="form-control" placeholder="Enter Nama karya" name="nama" 
                            value="<?php echo $row["nama"] ?>">
                        </div>
                        <div class="form-group">
                            <label>NIM :</label>
                            <input type="comment" class="form-control" placeholder="Enter NIM" name="nim" 
                            value="<?php echo $row["nim"] ?>">
                        </div>
                        <div class="form-group">
                            <label>Tempat Lahir:</label>
                            <input type="text" class="form-control" placeholder="Enter tempat lahir" name="tempatlahir" 
                            value="<?php echo $row["tempatlahir"] ?>">
                        </div>
                        <div class="form-group">
                            <label>Tempat Lahir:</label>
                            <input type="text" class="form-control" placeholder="Enter Tanggal Lahir" name="tanggallahir" 
                            value="<?php echo $row["tanggallahir"] ?>">
                        </div>
                        <div class="form-group">
                            <label>Hobi:</label>
                            <input type="text" class="form-control" placeholder="Enter Hobi" name="hobi" 
                            value="<?php echo $row["hobi"] ?>">
                        </div>
                        <div class="form-group">
                            <label>Alamat :</label>
                            <input type="text" class="form-control" placeholder="Enter Alamat" name="alamat" 
                            value="<?php echo $row["alamat"] ?>">
                        </div>
                        <div class="form-group">
                            <label>Nama Sekolah SD:</label>
                            <input type="text" class="form-control" placeholder="Enter Nama Sekolah" name="sd" 
                            value="<?php echo $row["sd"] ?>">
                        </div>
                        <div class="form-group">
                            <label>Nama Sekolah SMP:</label>
                            <input type="text" class="form-control" placeholder="Enter Nama Sekolah" name="smp" 
                            value="<?php echo $row["smp"] ?>">
                        </div>
                        <div class="form-group">
                            <label>Nama Sekolah SMK:</label>
                            <input type="text" class="form-control" placeholder="Enter Nama Sekolah" name="smk" 
                            value="<?php echo $row["smk"] ?>">
                        </div>
                        <div class="form-group">
                            <label>Nama Universitas:</label>
                            <input type="text" class="form-control" placeholder="Enter Nama Kampus" name="kampus" 
                            value="<?php echo $row["kampus"] ?>">
                        </div>
                        <div class="form-group">
                            <label>Foto:</label>
                            <input type="text" class="form-control" placeholder="Enter link foto" name="foto" 
                            value="<?php echo $row["foto"] ?>">
                        </div>
                        <input class="btn btn-primary" type="submit" id="proses" value="Submit">
                    </form><br><br><br><br>
                </div>
            </div>
    </div>
        <?php   
                    }
                }
            }
        ?>
<!-- JS, Popper.js, and jQuery -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
        <script>
            $(document).ready(function() {
                $('#proses').click(function(){
                    $('#myform').submit();
                });
            });
        </script>
</body>
</html>