<footer>
    <p>Footer</p>
</footer>