<?php
     include_once "koneksi.php";
     if (isset($_POST["id"])) {
            
        $nama = $_POST["nama"];
        $nim = $_POST["nim"];
        $tempatlahir = $_POST["tempatlahir"];
        $tanggallahir = $_POST["tanggallahir"];
        $hobi = $_POST["hobi"];
        $alamat = $_POST["alamat"];
        $sd = $_POST["sd"];
        $smp = $_POST["smp"];
        $smk = $_POST["smk"];
        $kampus = $_POST["kampus"];
        $foto = $_POST["foto"];
        $id = $_POST["id"];
        $strSQL = "UPDATE biodata SET nama='$nama', nim='$nim', tempatlahir='$tempatlahir', tanggallahir='$tanggallahir', hobi='$hobi', alamat='$alamat', sd='$sd', smp='$smp', smk='$smk', kampus='$kampus', foto='$foto' WHERE id='$id'";

        $runSQL = mysqli_query($conn, $strSQL);
        if ($runSQL) {
            header("location: admin.php");
        }  
        else {
            echo "Gagal";; 
        }       
    }    
?>