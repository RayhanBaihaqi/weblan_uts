<?php 
	function segitiga($alas, $tinggi)
		{
			return 0.5 * $alas * $tinggi;
		}
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 <?php 
 $a = 10;
 $t = 20;
  ?>
 Tabel Luas Segitiga
 <table width="800" border="1">
 	<th>No</th>
 	<th>Alas</th>
 	<th>Tinggi</th>
 	<th>Hasil</th>

 <tbody>
 	<tr>
 		<td>1</td>
 		<td><?php echo $a; ?></td>
 		<td><?php echo $t; ?></td>
 		<td><?php echo segitiga($a, $t);; ?></td>
 	</tr>
 </tbody> 
</table>
 </body>
 </html>