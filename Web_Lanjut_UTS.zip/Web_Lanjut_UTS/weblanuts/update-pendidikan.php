<?php
     include_once "koneksi.php";
     if (isset($_POST["nama"])) {
            
        $nama = $_POST["nama"];
        $jenjang = $_POST["jenjang"];
        $status = $_POST["status"];
        $pemimpin = $_POST["pemimpin"];
        $alamat = $_POST["alamat"];
        $kel = $_POST["kel"];
        $kec = $_POST["kec"];
        $kota = $_POST["kota"];
        $provinsi = $_POST["provinsi"];
        $foto = $_POST["foto"];
        $id = $_POST["id"];
        $strSQL = "UPDATE pendidikan SET nama='$nama', jenjang='$jenjang', status='$status', pemimpin='$pemimpin', alamat='$alamat', kel='$kel', kec='$kec', kota='$kota', provinsi='$provinsi', foto='$foto' WHERE id='$id'";

        $runSQL = mysqli_query($conn, $strSQL);
        if ($runSQL) {
            header("location: admin.php");
        }  
        else {
            die; 
        }       
    }    
?>