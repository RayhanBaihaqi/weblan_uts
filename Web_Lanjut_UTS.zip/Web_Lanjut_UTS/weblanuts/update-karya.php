<?php
     include_once "koneksi.php";
     if (isset($_POST["nama"])) {
            
        $nama = $_POST["nama"];
        $arti = $_POST["arti"];
        $tanggal = $_POST["tanggal"];
        $foto = $_POST["foto"];
        $id = $_POST["id"];
        $strSQL = "UPDATE karya SET nama='$nama', arti='$arti', tanggal='$tanggal', foto='$foto' WHERE id='$id'";

        $runSQL = mysqli_query($conn, $strSQL);
        if ($runSQL) {
            header("location: admin.php");
        }  
        else {
            die; 
        }       
    }    
?>